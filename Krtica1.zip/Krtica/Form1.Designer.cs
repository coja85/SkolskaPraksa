﻿namespace Krtica
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Score = new System.Windows.Forms.Label();
            this.Total = new System.Windows.Forms.Label();
            this.Miss = new System.Windows.Forms.Label();
            this.Restart = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.Exit = new System.Windows.Forms.Button();
            this.GameOver = new System.Windows.Forms.Label();
            this.WinBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.Location = new System.Drawing.Point(482, 278);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 75);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Score
            // 
            this.Score.AutoSize = true;
            this.Score.BackColor = System.Drawing.Color.MistyRose;
            this.Score.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Score.ForeColor = System.Drawing.Color.Red;
            this.Score.Location = new System.Drawing.Point(12, 9);
            this.Score.Name = "Score";
            this.Score.Size = new System.Drawing.Size(122, 39);
            this.Score.TabIndex = 1;
            this.Score.Text = "Score = 0";
            // 
            // Total
            // 
            this.Total.AutoSize = true;
            this.Total.BackColor = System.Drawing.Color.MistyRose;
            this.Total.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Total.ForeColor = System.Drawing.Color.Red;
            this.Total.Location = new System.Drawing.Point(12, 126);
            this.Total.Name = "Total";
            this.Total.Size = new System.Drawing.Size(174, 39);
            this.Total.TabIndex = 2;
            this.Total.Text = "Total Shots = 0";
            // 
            // Miss
            // 
            this.Miss.AutoSize = true;
            this.Miss.BackColor = System.Drawing.Color.MistyRose;
            this.Miss.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Miss.ForeColor = System.Drawing.Color.Red;
            this.Miss.Location = new System.Drawing.Point(12, 62);
            this.Miss.Name = "Miss";
            this.Miss.Size = new System.Drawing.Size(160, 39);
            this.Miss.TabIndex = 3;
            this.Miss.Text = "Miss Shot = 0";
            // 
            // Restart
            // 
            this.Restart.BackColor = System.Drawing.Color.MistyRose;
            this.Restart.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Restart.ForeColor = System.Drawing.Color.Red;
            this.Restart.Location = new System.Drawing.Point(862, 56);
            this.Restart.Name = "Restart";
            this.Restart.Size = new System.Drawing.Size(104, 45);
            this.Restart.TabIndex = 5;
            this.Restart.Text = "Restart";
            this.Restart.UseVisualStyleBackColor = false;
            this.Restart.Click += new System.EventHandler(this.Restart_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Exit
            // 
            this.Exit.BackColor = System.Drawing.Color.MistyRose;
            this.Exit.Font = new System.Drawing.Font("Agency FB", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Exit.ForeColor = System.Drawing.Color.Red;
            this.Exit.Location = new System.Drawing.Point(862, 6);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(104, 45);
            this.Exit.TabIndex = 6;
            this.Exit.Text = "EXIT";
            this.Exit.UseVisualStyleBackColor = false;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // GameOver
            // 
            this.GameOver.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GameOver.AutoSize = true;
            this.GameOver.BackColor = System.Drawing.Color.MistyRose;
            this.GameOver.Font = new System.Drawing.Font("Agency FB", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GameOver.ForeColor = System.Drawing.Color.Red;
            this.GameOver.Location = new System.Drawing.Point(387, 214);
            this.GameOver.Name = "GameOver";
            this.GameOver.Size = new System.Drawing.Size(0, 77);
            this.GameOver.TabIndex = 7;
            this.GameOver.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // WinBox
            // 
            this.WinBox.BackColor = System.Drawing.Color.MistyRose;
            this.WinBox.Font = new System.Drawing.Font("Agency FB", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WinBox.ForeColor = System.Drawing.Color.Red;
            this.WinBox.Location = new System.Drawing.Point(12, 204);
            this.WinBox.Multiline = true;
            this.WinBox.Name = "WinBox";
            this.WinBox.Size = new System.Drawing.Size(954, 87);
            this.WinBox.TabIndex = 8;
            this.WinBox.Text = "~~~YOU WON~~~";
            this.WinBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.WinBox.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(978, 496);
            this.Controls.Add(this.WinBox);
            this.Controls.Add(this.GameOver);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.Restart);
            this.Controls.Add(this.Miss);
            this.Controls.Add(this.Total);
            this.Controls.Add(this.Score);
            this.Controls.Add(this.pictureBox1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(994, 535);
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(994, 535);
            this.Name = "Form1";
            this.Text = "KRTICA";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseClick);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label Score;
        private System.Windows.Forms.Label Total;
        private System.Windows.Forms.Label Miss;
        private System.Windows.Forms.Button Restart;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button Exit;
        private System.Windows.Forms.Label GameOver;
        private System.Windows.Forms.TextBox WinBox;
    }
}

