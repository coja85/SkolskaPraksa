﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Krtica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Random r = new Random();
        
        int score = 0;
        int total_shots = 0;
        int miss_shots = 0;

        void fn_shot()
        {
            score++;
            Score.Text = "Score = " + score;
            total_shots++;
            Total.Text = "Total Shots = " + total_shots;
            pictureBox1.Visible = false;

        }
        void fn_miss_shot()
        {
            miss_shots++;
            Miss.Text = "Miss Shots = " + miss_shots;
            total_shots++;
            Total.Text = "Total Shots = " + total_shots;
            pictureBox1.Visible = false;

        }

        void restart()
        {
            score = 0;
            total_shots = 0;
            miss_shots = 0;
            Score.Text = "Score = " + score;
            Miss.Text = "Miss Shots = " + miss_shots;
            Total.Text = "Total Shots = " + total_shots;
            WinBox.Visible = false;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            pictureBox1.Visible=false;
            Thread.Sleep(300);
            pictureBox1.Visible = true;
            int x, y;
            x = r.Next(50, 900);
            y = r.Next(200, 400);
            pictureBox1.Location = new Point(x, y);
           

            if(miss_shots >= 10)
            {
                timer1.Stop();
                WinBox.Visible = true;
                WinBox.Text = "GAME OVER!";

                pictureBox1.Visible = false;

            }
            else if(score >= 30)
            {
                timer1.Stop();
                WinBox.Visible = true;
                pictureBox1.Visible = false;

            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            fn_shot();
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            fn_miss_shot();


        }

        private void Restart_Click(object sender, EventArgs e)
        {
            restart();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {

        }
    }
}
