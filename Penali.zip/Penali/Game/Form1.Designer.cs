﻿namespace Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblScore = new System.Windows.Forms.Label();
            this.lblMiss = new System.Windows.Forms.Label();
            this.left = new System.Windows.Forms.PictureBox();
            this.top = new System.Windows.Forms.PictureBox();
            this.right = new System.Windows.Forms.PictureBox();
            this.topRight = new System.Windows.Forms.PictureBox();
            this.topLeft = new System.Windows.Forms.PictureBox();
            this.keeper = new System.Windows.Forms.PictureBox();
            this.football = new System.Windows.Forms.PictureBox();
            this.KeeperTimer = new System.Windows.Forms.Timer(this.components);
            this.BallTimer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.left)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.top)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.right)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.topRight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.topLeft)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.keeper)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.football)).BeginInit();
            this.SuspendLayout();
            // 
            // lblScore
            // 
            this.lblScore.AutoSize = true;
            this.lblScore.BackColor = System.Drawing.Color.Transparent;
            this.lblScore.Font = new System.Drawing.Font("Chiller", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblScore.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblScore.Location = new System.Drawing.Point(12, 21);
            this.lblScore.Name = "lblScore";
            this.lblScore.Size = new System.Drawing.Size(107, 38);
            this.lblScore.TabIndex = 0;
            this.lblScore.Text = "Score: 0";
            // 
            // lblMiss
            // 
            this.lblMiss.AutoSize = true;
            this.lblMiss.BackColor = System.Drawing.Color.Transparent;
            this.lblMiss.Font = new System.Drawing.Font("Chiller", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMiss.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblMiss.Location = new System.Drawing.Point(780, 21);
            this.lblMiss.Name = "lblMiss";
            this.lblMiss.Size = new System.Drawing.Size(121, 38);
            this.lblMiss.TabIndex = 1;
            this.lblMiss.Text = "Missed: 0";
            // 
            // left
            // 
            this.left.BackColor = System.Drawing.Color.Yellow;
            this.left.BackgroundImage = global::Game.Properties.Resources.target;
            this.left.Image = global::Game.Properties.Resources.target;
            this.left.Location = new System.Drawing.Point(212, 255);
            this.left.Name = "left";
            this.left.Size = new System.Drawing.Size(40, 40);
            this.left.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.left.TabIndex = 2;
            this.left.TabStop = false;
            this.left.Tag = "left";
            this.left.Click += new System.EventHandler(this.SerGoalTargetEvent);
            // 
            // top
            // 
            this.top.BackColor = System.Drawing.Color.Yellow;
            this.top.BackgroundImage = global::Game.Properties.Resources.target;
            this.top.Image = global::Game.Properties.Resources.target;
            this.top.Location = new System.Drawing.Point(445, 84);
            this.top.Name = "top";
            this.top.Size = new System.Drawing.Size(40, 40);
            this.top.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.top.TabIndex = 3;
            this.top.TabStop = false;
            this.top.Tag = "top";
            this.top.Click += new System.EventHandler(this.SerGoalTargetEvent);
            // 
            // right
            // 
            this.right.BackColor = System.Drawing.Color.Yellow;
            this.right.BackgroundImage = global::Game.Properties.Resources.target;
            this.right.Image = global::Game.Properties.Resources.target;
            this.right.Location = new System.Drawing.Point(685, 255);
            this.right.Name = "right";
            this.right.Size = new System.Drawing.Size(40, 40);
            this.right.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.right.TabIndex = 4;
            this.right.TabStop = false;
            this.right.Tag = "right";
            this.right.Click += new System.EventHandler(this.SerGoalTargetEvent);
            // 
            // topRight
            // 
            this.topRight.BackColor = System.Drawing.Color.Yellow;
            this.topRight.BackgroundImage = global::Game.Properties.Resources.target;
            this.topRight.Image = global::Game.Properties.Resources.target;
            this.topRight.Location = new System.Drawing.Point(685, 84);
            this.topRight.Name = "topRight";
            this.topRight.Size = new System.Drawing.Size(40, 40);
            this.topRight.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.topRight.TabIndex = 5;
            this.topRight.TabStop = false;
            this.topRight.Tag = "topRight";
            this.topRight.Click += new System.EventHandler(this.SerGoalTargetEvent);
            // 
            // topLeft
            // 
            this.topLeft.BackColor = System.Drawing.Color.Yellow;
            this.topLeft.BackgroundImage = global::Game.Properties.Resources.target;
            this.topLeft.Image = global::Game.Properties.Resources.target;
            this.topLeft.Location = new System.Drawing.Point(212, 84);
            this.topLeft.Name = "topLeft";
            this.topLeft.Size = new System.Drawing.Size(40, 40);
            this.topLeft.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.topLeft.TabIndex = 6;
            this.topLeft.TabStop = false;
            this.topLeft.Tag = "topLeft";
            this.topLeft.Click += new System.EventHandler(this.SerGoalTargetEvent);
            // 
            // keeper
            // 
            this.keeper.BackColor = System.Drawing.Color.Transparent;
            this.keeper.Image = global::Game.Properties.Resources.stand_small;
            this.keeper.Location = new System.Drawing.Point(428, 182);
            this.keeper.Name = "keeper";
            this.keeper.Size = new System.Drawing.Size(82, 126);
            this.keeper.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.keeper.TabIndex = 7;
            this.keeper.TabStop = false;
            // 
            // football
            // 
            this.football.BackColor = System.Drawing.Color.Transparent;
            this.football.Image = global::Game.Properties.Resources.football;
            this.football.Location = new System.Drawing.Point(430, 500);
            this.football.Name = "football";
            this.football.Size = new System.Drawing.Size(50, 51);
            this.football.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.football.TabIndex = 8;
            this.football.TabStop = false;
            // 
            // KeeperTimer
            // 
            this.KeeperTimer.Enabled = true;
            this.KeeperTimer.Interval = 20;
            this.KeeperTimer.Tick += new System.EventHandler(this.KeeperTimerEvent);
            // 
            // BallTimer
            // 
            this.BallTimer.Enabled = true;
            this.BallTimer.Interval = 20;
            this.BallTimer.Tick += new System.EventHandler(this.BallTimerEvent);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Game.Properties.Resources.background;
            this.ClientSize = new System.Drawing.Size(899, 678);
            this.Controls.Add(this.football);
            this.Controls.Add(this.keeper);
            this.Controls.Add(this.topLeft);
            this.Controls.Add(this.topRight);
            this.Controls.Add(this.right);
            this.Controls.Add(this.top);
            this.Controls.Add(this.left);
            this.Controls.Add(this.lblMiss);
            this.Controls.Add(this.lblScore);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.left)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.top)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.right)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.topRight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.topLeft)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.keeper)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.football)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblScore;
        private System.Windows.Forms.Label lblMiss;
        private System.Windows.Forms.PictureBox left;
        private System.Windows.Forms.PictureBox top;
        private System.Windows.Forms.PictureBox right;
        private System.Windows.Forms.PictureBox topRight;
        private System.Windows.Forms.PictureBox topLeft;
        private System.Windows.Forms.PictureBox keeper;
        private System.Windows.Forms.PictureBox football;
        private System.Windows.Forms.Timer KeeperTimer;
        private System.Windows.Forms.Timer BallTimer;
    }
}

