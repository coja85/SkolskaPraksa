﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Game
{
    public partial class Form1 : Form
    {
        List<string> KeeperPosition = new List<string>()
        {
            "left", "right", "top", "topRight", "topLeft"
        };
        List<PictureBox> goalTarget;
        int ballX = 0;
        int ballY = 0;
        int goal = 0;
        int miss = 0;
        string state;
        string playerTarget;
        bool aimSet = false;
        Random random = new Random();

        public Form1()
        {
            InitializeComponent();
            goalTarget = new List<PictureBox> { left, right, top, topLeft, topRight};
        }


        private void SerGoalTargetEvent(object sender, EventArgs e)
        {
            if (aimSet == true)
                return;
            BallTimer.Start();
            KeeperTimer.Start();
            ChangeGoalKeeperImage();

            var senderObject = (PictureBox)sender;
            senderObject.BackColor = Color.Beige;

            if (senderObject.Tag.ToString() == "topRight")
            {
                ballX = -7;
                ballY = 15;
                playerTarget = senderObject.Tag.ToString();
                aimSet = true;
            }

            if (senderObject.Tag.ToString() == "right")
            {
                ballX = -11;
                ballY = 15;
                playerTarget = senderObject.Tag.ToString();
                aimSet = true;
            }

            if (senderObject.Tag.ToString() == "top")
            {
                ballX = 0;
                ballY = 20;
                playerTarget = senderObject.Tag.ToString();
                aimSet = true;
            }

            if (senderObject.Tag.ToString() == "topLeft")
            {
                ballX = 8;
                ballY = 15;
                playerTarget = senderObject.Tag.ToString();
                aimSet = true;
            }

            if (senderObject.Tag.ToString() == "left")
            {
                ballX = 7;
                ballY = 11;
                playerTarget = senderObject.Tag.ToString();
                aimSet = true;
            }

            CheckScore();

        }

        private void KeeperTimerEvent(object sender, EventArgs e)
        {
            switch(state)
            {
                case "left":

                    keeper.Left -= 6;
                    keeper.Top = 204;

                    break;

                case "right":

                    keeper.Left += 6;
                    keeper.Top = 204;

                    break;

                case "top":

                    keeper.Top -= 6;

                    break;

                case "topLeft":

                    keeper.Left -= 6;
                    keeper.Top -= 3;

                    break;

                case "topRight":

                    keeper.Left += 6;
                    keeper.Top -= 3;

                    break;

            }

            foreach(PictureBox x in goalTarget)
            {
                if(keeper.Bounds.IntersectsWith(x.Bounds))
                {
                    KeeperTimer.Stop();
                    keeper.Location = new Point(418, 169);
                    keeper.Image = Properties.Resources.stand_small;
                }
            }

        }

        private void BallTimerEvent(object sender, EventArgs e)
        {
            football.Left -= ballX;
            football.Top -= ballY;

            foreach (PictureBox x in goalTarget) 
            {
                if(football.Bounds.IntersectsWith(x.Bounds))
                {
                    football.Location = new Point(430, 500);
                    ballX = 0;
                    ballY = 0;
                    aimSet = false;
                    BallTimer.Stop();
                }
            }
        }

        private void CheckScore()
        {
            if(state == playerTarget) 
            {
                miss++;
                lblMiss.Text = "Missed: " + miss;
            }
            else
            {
                goal++;
                lblScore.Text = "Scored: " + goal; 
            }

            if(goal >= 10)
            {
                goal = 0;
                lblScore.Text = "Scored: " + goal;
                miss = 0;
                lblMiss.Text = "Missed: " + miss;
                MessageBox.Show("Nice, You Won");
            }

            if(miss >= 3)
            {
                goal = 0;
                lblScore.Text = "Scored: " + goal;
                miss = 0;
                lblMiss.Text = "Missed: " + miss;
                MessageBox.Show("Naah, You Lose");

            }

        }


        private void ChangeGoalKeeperImage()
        {
            KeeperTimer.Start();
            int i = random.Next(0, KeeperPosition.Count);
            state = KeeperPosition[i];

            switch (i) 
            {
                case 0:
                    keeper.Image = Properties.Resources.left_save_small; 
                    break;
                case 1:
                    keeper.Image = Properties.Resources.right_save_small;
                    break;
                case 2:
                    keeper.Image = Properties.Resources.top_save_small;
                    break;
                case 3:
                    keeper.Image = Properties.Resources.top_right_save_small;
                    break;
                case 4:
                    keeper.Image = Properties.Resources.top_left_save_small;
                    break;



            }

        }





    }
}
